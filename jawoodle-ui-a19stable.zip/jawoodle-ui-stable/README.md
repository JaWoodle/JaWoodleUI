# JaWoodle UI

## 7 Days 2 Die Modlet

A customized UI for JaWoodle and the JaWoodle Legends.

Minimal footprint with some Australian highlights
